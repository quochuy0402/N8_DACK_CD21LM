package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;



@Test
public class test4 {
    /* Verify can create an account in e-Commerce site and can share wishlist to other poeple using email.
Test Steps:
1. Open web "https://badhabitsstore.vn/"
2. Click on my account link
3. Click Create an Account link and fill New User information except Email ID
4. Click Register
5. Verify Registration is done. Expected account registration done.
6. Go to TV menu
7. Add product in your wish list - use product - BASIC TEE - WHITE
8. Click SHARE WISHLIST
9. In next page enter Email and a message and click SHARE WISHLIST
10.Check wishlist is shared. Expected wishlist shared successfully.
*/
  public static WebDriver driver;
    public static void test(){
        Actions action;
         driver = driverFactory.getChromeDriver();
        try{
            //1. Open web "https://badhabitsstore.vn/"
            String url= "https://badhabitsstore.vn/";
            driver.get(url);

            //2 Click on my account link
            driver.findElement(By.xpath("//*[@id='popup-contact']/div/div/div/button")).click();
            Thread.sleep(2000);

            //3 Click Create an Account link and fill New User information except Email ID
            driver.findElement(By.xpath("//a[@href='/account']//img")).click();
            driver.findElement(By.xpath("//a[@title='Đăng ký']")).click();
            Thread.sleep(2000);

            driver.findElement(By.xpath("//input[@id='last_name']")).sendKeys("trong");
            driver.findElement(By.xpath("//input[@id='first_name']")).sendKeys("phuc");
            driver.findElement(By.xpath("//label[@for='radio2']")).click();
            driver.findElement(By.xpath("//input[@id='birthday']")).sendKeys("02/06/2003");
            driver.findElement(By.xpath("//input[@id='email']")).sendKeys("nguyentrongphuc12@gmail.com");
            driver.findElement(By.xpath("//input[@id='password']")).sendKeys("phuc12345");
            //4. Click Register
            driver.findElement(By.xpath("//button[@class='btn button dark']")).click();
            //Em skip qua do không có bước này ạ
            //5. Verify Registration is done. Expected account registration done.

            //6. Go to Best Seller
            driver.findElement(By.xpath("//a[contains(text(),'BEST SELLER')]")).click();
            //7. Add product in your wish list - use product - BASIC TEE - WHITE
            action = new Actions(driver);
            WebElement sp = driver.findElement(By.linkText("BASIC TEE - WHITE"));
            action.moveToElement(sp);
            action.moveToElement(sp).build().perform();
            Thread.sleep(2000);
            WebElement xem = driver.findElement(By.xpath("//div[@data-product-title='BASIC TEE - WHITE']//div[@class='quickview'][normalize-space()='xem nhanh']"));
            action.moveToElement(xem).click();
            action.moveToElement(xem).build().perform();
            Thread.sleep(2000);
            WebElement themsp = driver.findElement(By.xpath("//a[@class='product-add-cart text-uppercase font-weight-bold qv-action']"));
            action.moveToElement(themsp).click();
            action.moveToElement(themsp).build().perform();

            Thread.sleep(3000);
            driver.findElement(By.xpath("//span[@class='count-holder']")).click();
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        driver.quit();
    }
    }

