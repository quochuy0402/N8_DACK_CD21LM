package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

@Test
public class test6 {
    /* Verify user is able to purchase product using registered email id(USE CHROME BROWSER)
Test Steps:
1. Go to http://live.techpanda.org/
2. Click on my account link
3. Login in application using previously created credential
4. Click on MY WISHLIST link
5. In next page, Click ADD TO CART link
6. Enter general shipping country, state/province and zip for the shipping cost estimate
7. Click Estimate
8. Verify Shipping cost generated
9. Select Shipping Cost, Update Total
10. Verify shipping cost is added to total
11. Click "Proceed to Checkout"
12a. Enter Billing Information, and click Continue
12b. Enter Shipping Information, and click Continue
13. In Shipping Method, Click Continue
14. In Payment Information select 'Check/Money Order' radio button. Click Continue
15. Click 'PLACE ORDER' button
16. Verify Oder is generated. Note the order number
*/
    public static void test(){
        WebDriver driver = driverFactory.getChromeDriver();
        try{
            //1. Open web "https://badhabitsstore.vn/"
            String url= "https://badhabitsstore.vn/";
            driver.get(url);
            //2. Click on my account link
            driver.findElement(By.xpath("//*[@id='popup-contact']/div/div/div/button")).click();
            Thread.sleep(2000);

            driver.findElement(By.xpath("//a[@href='/account']//img")).click();
            Thread.sleep(2000);
            //3. Login in application using previously created credential
            driver.findElement(By.xpath("//input[@id='customer_email']")).sendKeys("nguyentrongphuc12@gmail.com");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@id='customer_password']")).sendKeys("phuc12345");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//button[contains(text(),'Đăng nhập')]")).click();
            //4. Click on cart link and product payment
            driver.findElement(By.xpath("//span[@class='count-holder']")).click();
            driver.findElement(By.xpath("//a[@id='btnCart-checkout']")).click();
            Select select = new Select(driver.findElement(By.xpath("//select[@id='stored_addresses']")));
            select.selectByValue("0");
            driver.findElement(By.xpath("//input[@id='billing_address_full_name']")).sendKeys("Nguyen Trong Phuc");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@id='billing_address_phone']")).sendKeys("0387594040");
            Thread.sleep(2000);

            Select select1 = new Select(driver.findElement(By.xpath("//select[@id='customer_shipping_country']")));
            select1.selectByValue("241");

            Select select2 = new Select(driver.findElement(By.xpath("//select[@id='customer_shipping_province']")));
            select2.selectByValue("50");
            Thread.sleep(3000);
            Select select3 = new Select(driver.findElement(By.xpath("//select[@id='customer_shipping_district']")));
            select3.selectByValue("473");
            Thread.sleep(3000);
            Select select4 = new Select(driver.findElement(By.xpath("//select[@id='customer_shipping_ward']")));
            select4.selectByValue("27394");
            Thread.sleep(3000);
            driver.findElement(By.xpath("//input[@id='billing_address_address1']")).sendKeys("long huu dong can duoc long an");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@id='shipping_rate_id_1000078501']")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@id='payment_method_id_1000565228']")).click();
            Thread.sleep(2000);

            /*
            Em xin skip qua do trang web em không có những bước tường tự như vầy

            7. Click Estimate
            8. Verify Shipping cost generated
            9. Select Shipping Cost, Update Total
            10. Verify shipping cost is added to total
            11. Click "Proceed to Checkout"
            12a. Enter Billing Information, and click Continue
            12b. Enter Shipping Information, and click Continue
            13. In Shipping Method, Click Continue
            14. In Payment Information select 'Check/Money Order' radio button. Click Continue
            15. Click 'PLACE ORDER' button
            16. Verify Oder is generated. Note the order number
             */
        }catch (Exception e){
            e.printStackTrace();
        }
        driver.quit();
    }
}
