package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

@Test
public class test5 {
    /* Change the new address for the page
Test Steps:
1. Go to https://badhabitsstore.vn/
2. Click on my account link
3. Login in application using previously created credential
4. Click on address list link
5. In next page, Click enter new address link
6. Fill in all necessary information
7. Click submit
8. Verify the newly created address.
*/
    public static void test() {
        WebDriver driver = driverFactory.getChromeDriver();
        try {
            //1. Open web "https://badhabitsstore.vn/"
            String url = "https://badhabitsstore.vn/";
            driver.get(url);
            Thread.sleep(5000);
            driver.findElement(By.xpath("//*[@id='popup-contact']/div/div/div/button")).click();
            Thread.sleep(2000);
            //2. Click on my account link


            driver.findElement(By.xpath("//a[@href='/account']//img")).click();
            Thread.sleep(2000);
            //3. Login in application using previously created credential
            driver.findElement(By.xpath("//input[@id='customer_email']")).sendKeys("nguyentrongphuc12@gmail.com");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//input[@id='customer_password']")).sendKeys("phuc12345");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//button[contains(text(),'Đăng nhập')]")).click();
            //4. Click on address list link
            driver.findElement(By.xpath("//a[contains(text(),'Danh sách địa chỉ')]")).click();
            //5. In next page, Click enter new address link
            driver.findElement(By.xpath("//a[@class='add-new-address']")).click();
            //6. Fill in all necessary information
            driver.findElement(By.xpath("//input[@id='address_last_name_new']")).sendKeys("Nguyen");

            driver.findElement(By.xpath("//input[@id='address_first_name_new']")).sendKeys("Phuc");

            driver.findElement(By.xpath("//input[@for='address_company_new']")).sendKeys("ITC");

            driver.findElement(By.xpath("//input[@id='address_address1_new']")).sendKeys("ap dong xa long huu dong can duoc long an");

            driver.findElement(By.xpath("//input[@id='address_address2_new']")).sendKeys("ap dong xa long huu dong can duoc long an");

            Select select = new Select(driver.findElement(By.xpath("//*[@id=\"address_country_new\"]")));
            select.selectByVisibleText("Vietnam");
            driver.findElement(By.xpath("//input[@id='address_phone_new']")).sendKeys("0387504040");
            Thread.sleep(2000);

            //7. Click submit
            driver.findElement(By.xpath("//input[@value='Thêm mới']")).click();
            //8. Verify the newly created address.
            String order = driver.findElement(By.xpath("//*[@id=\"address_tables\"]")).getText();
            System.out.println(order);


        } catch (Exception e) {
            e.printStackTrace();
        }
        driver.quit();
    }
}

